#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/stat.h>

#define S_R 0
#define S_P 1
#define S_W 2

int WAIT(int id_sems,int n_sems)
{
  struct sembuf operation[1]={{n_sems,-1,0}};
  return semop(id_sems,operation,1);
}

int SIGNAL(int id_sems,int n_sems)
{
  struct sembuf operation[1]={{n_sems,+1,0}};
  return semop(id_sems,operation,1);
}

typedef struct MemoryStatus
{
  char frase[1024];
  int isnotfile1;
  int isnotfile2;
  int isPalindroma;
  int fine;
}MemoryStatus_t;

void clear(char *buffer)
{
  char a[strlen(buffer)];
  int x=0;

  for(int i=0;i<strlen(buffer);i++)
  {
    if(buffer[i]>='A' && buffer[i]<='Z')
    buffer[i]+=32;

    if(buffer[i]!='\n')
    {
      a[x]=buffer[i];
      x++;
    }

    else
    a[x]='\0';
  }

  strncpy(buffer,a,strlen(a));
}

int IsPalindroma(char *buffer,int isnotfile)
{
   int len=strlen(buffer);
   int i=0,j=len-2,count=0;
   
   if(isnotfile==1)
   j=len-1,len++;

   while(i<len-1)
   {
     
     if(buffer[i]==buffer[j])
     count++;
     
     if(count==len-1)
     return 1;

     i++;
     j--;
   }

   return 0;
  
}

void R(int id_sems,MemoryStatus_t * MemoryStatus,char *file)
{
  if(MemoryStatus->isnotfile1==0)
  {
    FILE *fd=fopen(file,"r+");

    while(1)
    {
      if(fgets(MemoryStatus->frase,sizeof(MemoryStatus->frase),fd)==NULL)
      break;
     
     
      //printf("R: ho letto %s",MemoryStatus->frase);

      SIGNAL(id_sems,S_P);
      WAIT(id_sems,S_R);
    }
    
    MemoryStatus->fine=1;
    SIGNAL(id_sems,S_P);
    exit(0);
  }

  else
  {
    strcpy(MemoryStatus->frase,file);
    MemoryStatus->fine=1;
    SIGNAL(id_sems,S_P);
    exit(0);
  }
}

void P(int id_sems,MemoryStatus_t * MemoryStatus)
{
  char buffer[1024];

  while(1)
  {
    if(MemoryStatus->fine==1)
    {
      MemoryStatus->fine=2;
      SIGNAL(id_sems,S_W);
      WAIT(id_sems,S_P);
      break;
    }

    WAIT(id_sems,S_P);

    strcpy(buffer,MemoryStatus->frase);
    clear(buffer);

    if(IsPalindroma(buffer,MemoryStatus->isnotfile1)==1)
    MemoryStatus->isPalindroma=1;
    
    else
    MemoryStatus->isPalindroma=0;

    SIGNAL(id_sems,S_W);
    WAIT(id_sems,S_P);

    SIGNAL(id_sems,S_R);
  }
  
  exit(0);
}

void W(int id_sems,MemoryStatus_t * MemoryStatus,char *file)
{
  int fd;

  if(MemoryStatus->isnotfile2==0)
  fd=open(file,O_WRONLY);

  while(1)
  {

    WAIT(id_sems,S_W);

    if(MemoryStatus->fine==2)
    {
      SIGNAL(id_sems,S_P);
      break;
    }
    
    if(MemoryStatus->isnotfile2==0)
    {
      if(MemoryStatus->isPalindroma==1)
      {
        if(write(fd,MemoryStatus->frase,strlen(MemoryStatus->frase))<0)
        {
          perror("write");
          exit(1);
        }

        else
        printf("W: scrivo sul file %s la parola %s",file,MemoryStatus->frase);
      }

      else
      printf("W: non è palindroma la parola %s",MemoryStatus->frase);

    }

    if(MemoryStatus->isnotfile2==1)
    {
      if(MemoryStatus->isPalindroma==1)
      printf("W: e' palindroma la parola %s",MemoryStatus->frase);
        
      else
      printf("W: non è palindroma la parola %s",MemoryStatus->frase);

    }

    SIGNAL(id_sems,S_P);
  }

  exit(0);
}

int main(int argc, char **argv)
{
  int id_sems,id_shm;
  int fd1=open(argv[1],O_RDONLY),fd2=open(argv[2],O_RDONLY);
  struct stat sd1,sd2;
  


  if(argc<2)
  {
    printf("Sintax error: ./palindrome-filter-3 [input file] [output file]\n");
    exit(1);
  }

  if((id_shm=shmget(IPC_PRIVATE,sizeof(MemoryStatus_t),IPC_CREAT|IPC_EXCL|0600))<0)
  {
    perror("shmget");
    exit(1);
  }
  
  MemoryStatus_t * MemoryStatus=shmat(id_shm,NULL,0);

  fstat(fd1,&sd1);
  fstat(fd2,&sd2);
  
  if(!S_ISREG(sd1.st_mode))
  MemoryStatus->isnotfile1=1;

  if(!S_ISREG(sd2.st_mode))
  MemoryStatus->isnotfile2=1;
  
  close(fd1);
  close(fd2);

  if((id_sems=semget(IPC_PRIVATE,3,IPC_CREAT|IPC_EXCL|0600))<0)
  {
    perror("semget");
    exit(1);
  }

  semctl(id_sems,S_R,SETVAL,0);
  semctl(id_sems,S_P,SETVAL,0);
  semctl(id_sems,S_W,SETVAL,0);

  if(fork()!=0)
  {
    if(fork()!=0)
    {
      P(id_sems,MemoryStatus);
    }
    else
    W(id_sems,MemoryStatus,argv[2]);
  }
  else
  R(id_sems,MemoryStatus,argv[1]);

  
  shmctl(id_shm,IPC_RMID,NULL);
  semctl(id_sems,0,IPC_RMID,0);

  exit(0);
}