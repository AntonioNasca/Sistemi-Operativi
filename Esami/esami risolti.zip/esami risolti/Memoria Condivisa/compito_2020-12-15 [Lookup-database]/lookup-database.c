#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <fcntl.h>
#include <wait.h>

#define S_IN1 0
#define S_IN2 1
#define S_DB 2
#define S_OUT 3

int WAIT(int id_sems,int n_sems)
{
  struct sembuf operation[1]={{n_sems,-1,0}};
  return semop(id_sems,operation,1);
}

int SIGNAL(int id_sems,int n_sems)
{
  struct sembuf operation[1]={{n_sems,+1,0}};
  return semop(id_sems,operation,1);
}


typedef struct QueryStatus
{
  char query1[1024];
  char query2[1024];
  int fine;
}QueryStatus_t;

typedef struct DatabaseStatus
{
  int process_id;
  int valid_record;
  int value_record;
  int fine;
}DatabaseStatus_t;

void clear(char *buffer)
{
  char a[strlen(buffer)];
  int x=0;

  for(int i=0;i<strlen(buffer);i++)
  {
    if(buffer[i]!='\n')
    {
      a[x]=buffer[i];
      x++;
    }

    else
    a[x]='\0';
  }

  strcpy(buffer,a);
}

void IN(int id_process,int id_sems,QueryStatus_t * QueryStatus,char *file1,char *file2)
{
  FILE *fd1=fopen(file1,"r+");
  FILE *fd2=fopen(file2,"r+");
  int i=1,j=1;

  while(1)
  {
    if(fgets(QueryStatus->query1,sizeof(QueryStatus->query1),fd1)==NULL)
    break;

    if(fgets(QueryStatus->query2,sizeof(QueryStatus->query2),fd2)==NULL)
    break;

    clear(QueryStatus->query1);
    clear(QueryStatus->query2);

    switch(id_process)
    {
      case 1: printf("IN1: inviata query n.%d '%s'\n",i,QueryStatus->query1);
              i++;
              break;

      case 2: printf("IN2: inviata query n.%d '%s'\n",j,QueryStatus->query2);
              j++;
              break;
    }
    
    SIGNAL(id_sems,S_DB);

    if(id_process==1)
    WAIT(id_sems,S_IN1);

    if(id_process==2)
    WAIT(id_sems,S_IN2);
  }

  QueryStatus->fine=1;
  SIGNAL(id_sems,S_DB);
  exit(0);
}

void DB(int id_sems,QueryStatus_t * QueryStatus,DatabaseStatus_t * DatabaseStatus,char *file)
{
  FILE *fd;
  int fd1=open(file,O_RDONLY);
  int n_righe=0;
  char buffer[1024];

  while(read(fd1,buffer,strlen(buffer))>0)
  {
    for(int i=0;i<strlen(buffer);i++)
    if(buffer[i]=='\n')
    n_righe++;
  }
  
  close(fd1);

  printf("DB:letti n. %d record da %s\n",n_righe,file);
  
   

  while(1)
  {
    WAIT(id_sems,S_DB);
    WAIT(id_sems,S_DB);

    if(QueryStatus->fine==1)
    {
       DatabaseStatus->fine=2;
       SIGNAL(id_sems,S_OUT);
       WAIT(id_sems,S_DB);
       break;
    }

    if((fd=fopen(file,"r+"))<0)
    {
      perror(file);
      exit(1);
    }
    
    for(int i=0;i<n_righe;i++)
    {
      if(fgets(buffer,sizeof(buffer),fd)==NULL)
      break;

      char frase[1024],valore[1024];
      int x=0,y=0;

      for(int i=0;i<strlen(buffer);i++)
      {
        if(buffer[i]>='a' && buffer[i]<='z')
        {
          frase[x]=buffer[i];
          x++;
        }

        if(buffer[i]>='0' && buffer[i]<='9')
        {
          valore[y]=buffer[i];
          y++;
        }
      }

      frase[x]='\0';
      valore[y]='\0';
      int val=atoi(valore);

      if(strcmp(frase,QueryStatus->query1)==0)
      {
        printf("DB: query '%s' da IN1 trovata con valore %d\n",QueryStatus->query1,val);
        DatabaseStatus->process_id=1;
        DatabaseStatus->valid_record=1;
        DatabaseStatus->value_record=val;

        SIGNAL(id_sems,S_OUT);
        WAIT(id_sems,S_DB);
      }

      if(strcmp(frase,QueryStatus->query2)==0)
      {
        printf("DB: query '%s' da IN2 trovata con valore %d\n",QueryStatus->query2,val);
        DatabaseStatus->process_id=2;
        DatabaseStatus->valid_record=1;
        DatabaseStatus->value_record=val;

        SIGNAL(id_sems,S_OUT);
        WAIT(id_sems,S_DB);
      }

    }

    SIGNAL(id_sems,S_IN1);
    SIGNAL(id_sems,S_IN2);
  }

  exit(0);
}

void OUT(int id_sems,DatabaseStatus_t * DatabaseStatus)
{
  int record_valid_in1=0,record_valid_in2=0;
  int record_value_in1=0,record_value_in2=0;

  while(1)
  {
    if(DatabaseStatus->fine==2)
    {
      SIGNAL(id_sems,S_DB);
      break;
    }

    WAIT(id_sems,S_OUT);
    
    if(DatabaseStatus->process_id==1 && DatabaseStatus->valid_record==1)
    {
      record_valid_in1++;
      record_value_in1+=DatabaseStatus->value_record;
    }

    if(DatabaseStatus->process_id==2 && DatabaseStatus->valid_record==1)
    {
      record_valid_in2++;
      record_value_in2+=DatabaseStatus->value_record;
    }
    
    DatabaseStatus->valid_record=0;

    SIGNAL(id_sems,S_DB);
  }

  printf("OUT: ricevuti n.%d valori validi per IN1 con totale %d\n",record_valid_in1,record_value_in1);
  printf("OUT: ricevuti n.%d valori validi per IN2 con totale %d\n",record_valid_in2,record_value_in2);
  exit(0);

}

int main(int argc, char **argv)
{
  int id_sems,id_shm1,id_shm2;

  if(argc<4)
  {
    printf("Sintax error: ./lookup-database <db-file> <query-file-1> <query-file-2>\n");
    exit(1);
  }

  if((id_shm1=shmget(IPC_PRIVATE,sizeof(QueryStatus_t),IPC_CREAT|IPC_EXCL|0600))<0)
  {
    perror("shmget1");
    exit(1);
  }

  if((id_shm2=shmget(IPC_PRIVATE,sizeof(DatabaseStatus_t),IPC_CREAT|IPC_EXCL|0600))<0)
  {
    perror("shmget2");
    exit(1);
  }

  if((id_sems=semget(IPC_PRIVATE,4,IPC_CREAT|IPC_EXCL|0600))<0)
  {
    perror("semget");
    exit(1);
  }

  QueryStatus_t * QueryStatus=shmat(id_shm1,NULL,0);
  DatabaseStatus_t * DatabaseStatus=shmat(id_shm2,NULL,0);

  semctl(id_sems,S_IN1,SETVAL,0);
  semctl(id_sems,S_IN2,SETVAL,0);
  semctl(id_sems,S_DB,SETVAL,0);
  semctl(id_sems,S_OUT,SETVAL,0);

  if(fork()!=0)
  {
    if(fork()!=0)
    {
      if(fork()!=0)
      {
        if(fork()!=0)
        {
          wait(NULL);
          wait(NULL);
          wait(NULL);
          wait(NULL);
        }
        else
        OUT(id_sems,DatabaseStatus);
      }
      else
      DB(id_sems,QueryStatus,DatabaseStatus,argv[1]);
    }
    else
    IN(2,id_sems,QueryStatus,argv[2],argv[3]);
  }
  else
  IN(1,id_sems,QueryStatus,argv[2],argv[3]);

  shmctl(id_shm1,IPC_RMID,NULL);
  shmctl(id_shm2,IPC_RMID,NULL);
  semctl(id_sems,0,IPC_RMID,0);

  exit(0);


}