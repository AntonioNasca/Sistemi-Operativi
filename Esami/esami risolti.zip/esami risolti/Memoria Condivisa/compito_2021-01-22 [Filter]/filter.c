#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <string.h>

int WAIT(int id_sems,int n_sem)
{
  struct sembuf operation[1]={{n_sem,-1,0}};
  return semop(id_sems,operation,1);
}

int SIGNAL(int id_sems,int n_sem)
{
  struct sembuf operation[1]={{n_sem,+1,0}};
  return semop(id_sems,operation,1);
}

typedef struct  FilterStatus
{
  char frase[1024];
  int fine;
}FilterStatus_t;

void clear(char *frase,int len)
{
  char a[len];
  int x=0;

  for(int i=0;i<len;i++)
  {
    if(frase[i]!='\n' && frase[i]!='^' && frase[i]!='_')
    {
      a[x]=frase[i];
      x++;
    }

    else
    {
      a[x]='\0';
      x=0;
    }
  }

  strncpy(frase,a,len);
}

void maiusc(FilterStatus_t * FilterStatus,char *input)
{

   
  if(strstr(FilterStatus->frase,input))
  {
    for(int i=0;i<strlen(input);i++)
    {
      for(int j=0;j<strlen(FilterStatus->frase);j++)
      {
       if(FilterStatus->frase[j]==input[i])
       FilterStatus->frase[j]-=32;
      }
    }

  }

}

void minusc(FilterStatus_t * FilterStatus,char *input)
{

   
  if(strstr(FilterStatus->frase,input))
  {
    for(int i=0;i<strlen(input);i++)
    {
      for(int j=0;j<strlen(FilterStatus->frase);j++)
      {
       if(FilterStatus->frase[j]==input[i])
       FilterStatus->frase[j]+=32;
      }
    }

  }

}

//La funzione sostituisco non è completa, in questo momento cerca una lettera x e la sostituisce con a, con il comando %x,a
void sostituisci(char *frase,char *input,FilterStatus_t * FilterStatus)
{
  char frase1[strlen(input)];
  char frase2[strlen(input)];
  int x=0,y=0;
  char *trovato;
  
  clear(frase,strlen(frase));
  int i;
  for(i=0;i<strlen(input);i++)
  {
    if(input[i]!=',')
    {
       if(input[i]!='%')
       {
        frase1[x]=input[i];
        x++;
       }
    }

    else
    {
      frase1[x]='\0';
      x=0;
      break;
    }
  }

  int j=i;

  for(int j=i;j<strlen(input);j++)
  {
    if(input[j]!='\n')
    {
      if(input[j]!=',')
      {
        frase2[y]=input[j];
        y++;
      }
    }

    else
    {
      frase2[y]='\0';
      y=0;
      break;
    }
  }
  
  if((trovato=strstr(frase,frase1))!=NULL)
  {
    for(int i=0;i<strlen(frase);i++)
    {
      if(frase[i]==frase1[0])
      frase[i]=frase2[0];
    }   
  }

  strcpy(FilterStatus->frase,frase);
}

void Filter(int id_filter,int id_sems,FilterStatus_t * FilterStatus,char *parola)
{
  char input[strlen(parola)];

  while(FilterStatus->fine!=1)
  {
    WAIT(id_sems,id_filter);
    
    if(FilterStatus->fine==1)
    exit(0);
    
    strcpy(input,parola);


    if(input[0]=='^')
    {
      clear(input,strlen(input));
      maiusc(FilterStatus,input);
    }
    
    
    if(input[0]=='_')
    {
      clear(input,strlen(input));
      minusc(FilterStatus,input);
    }

    if(input[0]=='%')
    {
      sostituisci(FilterStatus->frase,input,FilterStatus);
    }
    

    SIGNAL(id_sems,id_filter+1);

  }

  
}

void P(int id_sems,FilterStatus_t * FilterStatus,char *file,int n_process)
{ 
  FILE *fd;
  char buffer[1024];

  if((fd=fopen(file,"r+"))<0)
  {
    perror(file);
    exit(1);
  }


  while(FilterStatus->fine!=1)
  {
    if((fgets(buffer,sizeof(buffer),fd))==NULL)
      {
        FilterStatus->fine=1;
        break;
      }
    
    strcpy(FilterStatus->frase,buffer);

    SIGNAL(id_sems,0);

    WAIT(id_sems,n_process);

    printf("%s",FilterStatus->frase);
  }
  
}

int main(int argc, char **argv)
{
  int id_shm,id_sems;

  if(argc<2)
  {
    printf("Sintax error: filter <file.txt> <filter-1> [filter-2] [...]\n");
    exit(1);
  }

  if((id_shm=shmget(IPC_PRIVATE,sizeof(FilterStatus_t),IPC_CREAT|IPC_EXCL|0600))<0)
  {
    perror("shmget");
    exit(1);
  }

   int n_process=argc-2;
   FilterStatus_t * FilterStatus=shmat(id_shm,NULL,0);

  if((id_sems=semget(IPC_PRIVATE,n_process+1,IPC_CREAT|IPC_EXCL|0600))<0)
  {
    perror("semget");
    exit(1);
  }
  
  int initialize_sems[n_process+1];

  for(int i=0;i<n_process+1;i++)
  initialize_sems[i]=0;

  semctl(id_sems,0,SETALL,initialize_sems);

  for(int i=0;i<n_process;i++)
  {
    pid_t pid=fork();

    if(pid==0)
    Filter(i,id_sems,FilterStatus,argv[i+2]);
  }
  
  P(id_sems,FilterStatus,argv[1],n_process);

  shmctl(id_shm,IPC_RMID,NULL);
  semctl(id_sems,0,IPC_RMID,0);

}