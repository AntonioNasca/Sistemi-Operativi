#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <unistd.h>
#include <time.h>
#include <wait.h>

#define S_P1 0
#define S_P2 1
#define S_G 2
#define S_T 3

int WAIT(int id_sems,int nsems)
{
  struct sembuf operation[1]={{nsems,-1,0}};
  return semop(id_sems,operation,1);
}

int SIGNAL(int id_sems,int nsems)
{
  struct sembuf operation[1]={{nsems,+1,0}};
  return semop(id_sems,operation,1);
}

typedef struct GameStatus
{
  char mossa_p1;
  char mossa_p2;
  int n_partite;
  int winner;
}GameStatus_t;

char Random()
{
  int n=rand()%2;

  switch(n)
  {
    case 0: return 'C';
    case 1: return 'F';
    case 2: return 'S';
  }
}

int Winner(GameStatus_t * GameStatus)
{
  if(GameStatus->mossa_p1==GameStatus->mossa_p2)
  return 0;

  switch (GameStatus->mossa_p1)
  {
     case 'C':
     switch(GameStatus->mossa_p2)
     {
       case 'F': return 2;
       case 'S': return 1;
     }

     case 'F':
     switch(GameStatus->mossa_p2)
     {
       case 'C': return 1;
       case 'S': return 2;
     }

     case 'S':
     switch(GameStatus->mossa_p2)
     {
       case 'F': return 1;
       case 'C': return 2;
     }
  }
}

void P(int id_process,int id_sems,GameStatus_t * GameStatus)
{
  

  srand(time(NULL)+id_process);

  while(GameStatus->n_partite > 0)
  {
    char mossa=Random();

    switch(id_process)
    {
      case 1: GameStatus->mossa_p1=mossa;
              printf("P%d, mossa %c\n",id_process,GameStatus->mossa_p1);
              break;

      case 2: GameStatus->mossa_p2=mossa;
              printf("P%d, mossa %c\n",id_process,GameStatus->mossa_p2);
              break;
    }

    SIGNAL(id_sems,S_G);

    if(id_process==1)
    WAIT(id_sems,S_P1);

    if(id_process==2)
    WAIT(id_sems,S_P2);
  }

  exit(0);
}

void G(int id_sems,GameStatus_t * GameStatus)
{
  while(GameStatus->n_partite > 0)
  {
    WAIT(id_sems,S_G);
    WAIT(id_sems,S_G);

    int winner=Winner(GameStatus);
    
    if(winner==1)
    {
      printf("G: partita n.%d vinta da P%d\n",GameStatus->n_partite,GameStatus->winner);
      GameStatus->winner=1;
    }
    
    if(winner==2)
    {
      printf("G: partita n.%d vinta da P%d\n",GameStatus->n_partite,GameStatus->winner);
      GameStatus->winner=2;
    }

    if(winner==0)
    {
      printf("G: partita n.%d patta\n",GameStatus->n_partite);
      GameStatus->winner=2;
    }
    
    SIGNAL(id_sems,S_T);
    WAIT(id_sems,S_G);

    SIGNAL(id_sems,S_P1);
    SIGNAL(id_sems,S_P2);
  }

  exit(0);
}

void T(int id_sems,GameStatus_t * GameStatus)
{
  int points_p1=0,points_p2=0,points_patte=0;

  while(GameStatus->n_partite > 0)
  {
    WAIT(id_sems,S_T);
    
    if(GameStatus->winner==1)
    {
      points_p1++;
      GameStatus->n_partite--;
    }

    if(GameStatus->winner==2)
    {
      points_p2++;
      GameStatus->n_partite--;
    }

    if(GameStatus->winner==0)
    points_patte++;

    SIGNAL(id_sems,S_G);
  }

  printf("T: classifica finale: P1=%d P2=%d\n",points_p1,points_p2);

  if(points_p1>points_p2)
  printf("T: vincitore del torneo P1\n");

  else
  printf("T: vincitore del torneo P2\n");

  exit(0);
}

int main(int argc, char **argv)
{
   int id_shm,id_sems;

   if(argc<2)
   {
     printf("Sintax error: ./morra-cinese <numero-partite>\n");
     exit(1);
   }

   if((id_shm=shmget(IPC_PRIVATE,sizeof(GameStatus_t),IPC_CREAT|IPC_EXCL|0600))<0)
   {
     perror("shmget");
     exit(1);
   }

   if((id_sems=semget(IPC_PRIVATE,4,IPC_CREAT|IPC_EXCL|0600))<0)
   {
     perror("semget");
     exit(1);
   }

   GameStatus_t * GameStatus=shmat(id_shm,NULL,0);
   GameStatus->n_partite=atoi(argv[1]);

   semctl(id_sems,S_P1,SETVAL,0);
   semctl(id_sems,S_P2,SETVAL,0);
   semctl(id_sems,S_G,SETVAL,0);
   semctl(id_sems,S_T,SETVAL,0);

   if(fork()!=0)
   {
     if(fork()!=0)
     {
       if(fork()!=0)
       {
         if(fork()!=0)
         {
           wait(NULL);
           wait(NULL);
           wait(NULL);
           wait(NULL);
         }
         else
         T(id_sems,GameStatus);
       }
       else
       G(id_sems,GameStatus);
     }
     else
     P(2,id_sems,GameStatus);
   }
   else
   P(1,id_sems,GameStatus);

   shmctl(id_shm,IPC_RMID,NULL);
   semctl(id_sems,0,IPC_RMID,0);

   exit(0);
}