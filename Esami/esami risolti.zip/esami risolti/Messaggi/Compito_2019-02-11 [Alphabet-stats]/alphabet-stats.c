#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/msg.h>
#include <string.h>
#include <wait.h>

typedef struct 
{
  long mtype;
  char mtext[1024];
}msg1;

typedef struct 
{
  long mtype;
  char mtext[1024];
  int arr_statistiche[26];
}msg2;

void Reader(int id_reader,int id_msg1,char *file)
{
  msg1 messaggio;
  FILE *fd=fopen(file,"r+");

  while(1)
  {
    if(fgets(messaggio.mtext,sizeof(messaggio.mtext),fd)==NULL)
    {
      messaggio.mtype=1;
      strcpy(messaggio.mtext,"fine");
      
      if(msgsnd(id_msg1,&messaggio,strlen(messaggio.mtext)+1,0)<0)
      {
        perror("msgsnd");
        exit(1);
      }

      //else
      //printf("Reader%d: ho inviato %s\n",id_reader,messaggio.mtext);

      break;
    }
    
    messaggio.mtype=1;
    if(msgsnd(id_msg1,&messaggio,strlen(messaggio.mtext)+1,0)<0)
      {
        perror("msgsnd");
        exit(1);
      }

      //else
      //printf("Reader%d: ho inviato %s\n",id_reader,messaggio.mtext);
   
  }

  exit(0);
}

void Counter(int id_msg1,int id_msg2,int ultimo_processo)
{
  msg1 messaggio1;
  msg2 messaggio2;
  int arr_frq[26],finish=0,x;
  char arr_minusc[26],arr_maiusc[26];

  x=0;
  for(char a='a'; a<='z'; a++)
  {
    arr_minusc[x]=a;
    x++;
  }

  x=0;
  for(char a='A'; a<='Z'; a++)
  {
    arr_maiusc[x]=a;
    x++;
  }


  while(1)
  {
    if(msgrcv(id_msg1,&messaggio1,sizeof(messaggio1),0,0)<0)
    {
      perror("msgrcv");
      exit(1);
    }

    if(strcmp(messaggio1.mtext,"fine")==0)
    {
      finish++;

      if(finish==ultimo_processo)
      {
        messaggio2.mtype=1;
        strcpy(messaggio2.mtext,"fine");

        if(msgsnd(id_msg2,&messaggio2,strlen(messaggio2.mtext)+1,0)<0)
        {
          perror("msgsnd");
          exit(1);
        }

        //else
        //printf("Counter: invio fine\n");

        break;
      }
    }

    for(int i=0;i<26;i++)
    arr_frq[i]=0;

    for(int i=0;i<strlen(messaggio1.mtext);i++)
    for(int j=0;j<26;j++)
    if(messaggio1.mtext[i]==arr_minusc[j] || messaggio1.mtext[i]==arr_maiusc[j])
    arr_frq[j]++;

    for(int i=0;i<26;i++)
    messaggio2.arr_statistiche[i]=arr_frq[i];
    
    /*printf("Counter:");
    for(int i=0;i<26;i++)
    printf(" %c=%d",arr_minusc[i],messaggio2.arr_statistiche[i]);
    printf("\n");*/

    messaggio2.mtype=1;
  

        if(msgsnd(id_msg2,&messaggio2,sizeof(messaggio2),0)<0)
        {
          perror("msgsnd");
          exit(1);
        }
  
  }

  exit(0);
}

void Father(int id_msg2)
{
  msg2 messaggio2;
  int sum_arr[26],x=0;
  char arr_minusc[26];

  for(char a='a'; a<='z';a++)
  {
    arr_minusc[x]=a;
    x++;
  }
  
  for(int i=0;i<26;i++)
  sum_arr[i]=0;

  while(1)
  {
    if(msgrcv(id_msg2,&messaggio2,sizeof(messaggio2),0,0)<0)
    {
      //perror("msgrcv");
      exit(1);
    }

    if(strcmp(messaggio2.mtext,"fine")==0)
    break;

    else
    {
      for(int i=0;i<26;i++)
      sum_arr[i]+=messaggio2.arr_statistiche[i];

    }
  }
      
      printf("Processo padre:");
      for(int i=0;i<26;i++)
      printf("%c=%d ",arr_minusc[i],sum_arr[i]);
      printf("\n");
}

int main(int argc, char **argv)
{
  int id_msg1,id_msg2;

  if(argc<2)
  {
    printf("Sintax error: ./alphabet-stats <file-1> <file-2> ... <file-n>\n");
    exit(1);
  }

  if((id_msg1=msgget(IPC_PRIVATE,IPC_CREAT|IPC_EXCL|0600))<0)
  {
    perror("msgget1");
    exit(1);
  }

  if((id_msg2=msgget(IPC_PRIVATE,IPC_CREAT|IPC_EXCL|0600))<0)
  {
    perror("msgget2");
    exit(1);
  }

  int n_process=argc-1;

  for(int i=0;i<n_process;i++)
  {
    pid_t pid1=fork();

    if(pid1==0)
    Reader(i,id_msg1,argv[i+1]);
  }

  pid_t pid2=fork();

  if(pid2==fork())
  Counter(id_msg1,id_msg2,n_process);
 
  waitpid(pid2,NULL,0);

  Father(id_msg2);
  

  msgctl(id_msg1,IPC_RMID,NULL);
  msgctl(id_msg2,IPC_RMID,NULL);

  exit(0);
}