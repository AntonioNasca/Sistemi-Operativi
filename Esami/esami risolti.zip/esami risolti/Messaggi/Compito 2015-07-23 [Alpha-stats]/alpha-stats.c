#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/msg.h>
#include <string.h>

typedef struct 
{
  long mtype;
  char mtext[1024];
  int statistiche_arr[26];
}msg;

void T(int id_process,int id_msg,char *file)
{
  FILE *fd=fopen(file,"r+");
  msg messaggio;
  int arr_frq[26],x;
  char arr_minusc[26],arr_maiusc[26];
  
  x=0;
  for(char a='a'; a<='z';a++)
  {
    arr_minusc[x]=a;
    x++;
  }

  x=0;
  for(char a='A'; a<='Z';a++)
  {
    arr_maiusc[x]=a;
    x++;
  }

  while(1)
  {
     if(fgets(messaggio.mtext,sizeof(messaggio.mtext),fd)==NULL)
     break;

     for(int i=0;i<26;i++)
     {
       arr_frq[i]=0;
       messaggio.statistiche_arr[i]=0;
     }
    

    for(int i=0;i<strlen(messaggio.mtext);i++)
    {
      for(int j=0;j<26;j++)
      {
        if(messaggio.mtext[i]==arr_minusc[j] || messaggio.mtext[i]==arr_maiusc[j])
        arr_frq[j]++;
      }
    }

    for(int i=0;i<26;i++)
    messaggio.statistiche_arr[i]=arr_frq[i];
    
    printf("processo T-%d su file '%s':",id_process,file);
    for(int i=0;i<26;i++)
    printf("%c=%d ",arr_minusc[i],messaggio.statistiche_arr[i]);
    printf("\n");
    
    messaggio.mtype=1;

    if(msgsnd(id_msg,&messaggio,sizeof(messaggio),0)<0)
    {
      perror("msgsnd");
      exit(1); 
    } 

  }
   

  strcpy(messaggio.mtext,"fine");
  messaggio.mtype=1;

  if(msgsnd(id_msg,&messaggio,strlen(messaggio.mtext)+1,0)<0)
  {
    perror("msgsnd");
    exit(1);
  }

  exit(0);
}

void P(int id_msg,int n_process)
{
  msg messaggio;
  int x=0,finish=0,salta=0;
  int arr_sum[26];
  char arr_minusc[26];
  
  for(char a='a'; a<='z';a++)
  {
    arr_minusc[x]=a;
    x++;
  }


  for(int i=0;i<26;i++)
  arr_sum[i]=0;


  while(1)
  {
    msgrcv(id_msg,&messaggio,sizeof(messaggio),0,0);

    if(strcmp(messaggio.mtext,"fine")==0)
    {
      finish++;
      salta++;
    }

    if(finish==n_process)
    break;
    
    //Faccio questo controllo perchè il messaggio dei processi che terminano, (quando inviano "fine") potrebbero far fare delle somme al padre
    //che non servono.

    if(salta!=1)
    {
      for(int i=0;i<26;i++)
      arr_sum[i]+=messaggio.statistiche_arr[i];
    }
    
    salta=0;
    
  }
  

   int j=0,max=-1;
   for(int i=0;i<26;i++)
   {
     if(arr_sum[i]>max)
     {
       max=arr_sum[i];
       j=i;
     }

   }

   printf("Processo padre:");
   for(int i=0;i<26;i++)
   printf(" %c=%d ",arr_minusc[i],arr_sum[i]);
   printf("\n");

   printf("Lettera più utilizzata: %c\n",arr_minusc[j]);

}


int main(int argc, char**argv)
{
  int id_msg;

  if(argc<2)
  {
    printf("Sintax error: ./alpha-stats <file-1> <file-2> <...>\n");
    exit(1);
  }

  if((id_msg=msgget(IPC_PRIVATE,IPC_CREAT|IPC_EXCL|0600))<0)
  {
    perror("msgget");
    exit(1);
  }

  int n_process=argc-1;

  for(int i=0;i<n_process;i++)
  {
    pid_t pid=fork();

    if(pid==0)
    T(i,id_msg,argv[i+1]);
  }

  P(id_msg,n_process);
   
  sleep(1);
  msgctl(id_msg,IPC_RMID,NULL);

  exit(0);
}