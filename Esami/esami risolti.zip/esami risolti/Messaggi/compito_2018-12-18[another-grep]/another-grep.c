#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/msg.h>
#include <unistd.h>

typedef struct 
{
  long mtype;
  char mtext[1024];
}msg;

void R(int id_msg,char *file)
{
  msg messaggio;
  FILE *fd=fopen(file,"r+");

  while(1)
  {
    if(fgets(messaggio.mtext,sizeof(messaggio.mtext),fd)==NULL)
    {
      strcpy(messaggio.mtext,"fine");
      messaggio.mtype=1;

      if(msgsnd(id_msg,&messaggio,strlen(messaggio.mtext)+1,0)<0)
      {
        perror("msgsnd");
        exit(1);
      }

      //else
      //printf("\nR: ho inviato %s\n",messaggio.mtext);

     break;
    }
     
    messaggio.mtype=1;
    if(msgsnd(id_msg,&messaggio,strlen(messaggio.mtext)+1,0)<0)
    {
      perror("msgsnd");
      exit(1);
    }

    //else
    //printf("R: ho inviato %s",messaggio.mtext);
  }

  exit(0);
}

void P(int id_msg,int *pipe1,char *parola)
{
  FILE *pipe_write=fdopen(pipe1[1],"w");
  msg messaggio;

  close(pipe1[0]);

  while(1)
  {
    if(msgrcv(id_msg,&messaggio,sizeof(messaggio),0,0)<0)
    {
      perror("msgrcv");
      exit(1);
    }

    if(strcmp(messaggio.mtext,"fine")==0)
    break;
    
    

    if(strstr(messaggio.mtext,parola))
    {
      //printf("P: invio %s",messaggio.mtext);

      fprintf(pipe_write,"%s",messaggio.mtext);
      fflush(pipe_write);
    }
  }

  exit(0);
}

void W(int *pipe1)
{
  FILE *pipe_read=fdopen(pipe1[0],"r");
  char buffer[1024];

  close(pipe1[1]);

  while(1)
  {
    if(fgets(buffer,sizeof(buffer),pipe_read)==NULL)
    break;

    else
    {
      printf("W:%s",buffer);
    }
  }

  exit(0);
}

int main(int argc, char **argv)
{
  int id_msg,pipe1[2];

  if(argc<3)
  {
    printf("Sintax error: ./another-grep <parola> <file>\n");
    exit(1);
  }

  if((id_msg=msgget(IPC_PRIVATE,IPC_CREAT|IPC_EXCL|0600))<0)
  {
    perror("msgget");
    exit(1);
  }

  if(pipe(pipe1)<0)
  {
    perror("pipe");
    exit(1);
  }

  if(fork()!=0)
  {
    if(fork()!=0)
    {
      P(id_msg,pipe1,argv[1]);
    }
    else
    W(pipe1);
  }
  else
  R(id_msg,argv[2]);
  

  msgctl(id_msg,IPC_RMID,NULL);

  exit(0);
}