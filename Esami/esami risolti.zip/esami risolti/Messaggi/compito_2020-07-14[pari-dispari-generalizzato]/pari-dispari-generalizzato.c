#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/msg.h>
#include <fcntl.h>
#include <string.h>
#include <time.h>

typedef struct 
{  
  long mtype;
  char mtext[1024];
  int mnumber;
}msg;

void P(int id_player,int id_msg)
{
  msg messaggio;
  int number;

  srand(time(NULL)+id_player);

  while(1)
  {
    number=rand()%9;

    switch(id_player)
    {
      case 0: //printf("P%d, aspetto il messaggio\n",id_player);
              if(msgrcv(id_msg,&messaggio,sizeof(messaggio),1,0)<0)
              {
                perror("msgrcv");
                exit(1);
              }

              if(strcmp(messaggio.mtext,"iniziamo")==0)
              {
                
                messaggio.mnumber=number;
                messaggio.mtype=1;

                if(msgsnd(id_msg,&messaggio,sizeof(messaggio),0)<0)
                {perror("msgsnd"); exit(1);}

                else
                printf("P%d, mossa %d\n",id_player,messaggio.mnumber);

                usleep(rand()%10000);
              }

              if(strcmp(messaggio.mtext,"fine")==0)
              {
                printf("P%d,ESCO\n",id_player);
                exit(0);
              }

              break;

        case 1: //printf("P%d, aspetto il messaggio\n",id_player);
              if(msgrcv(id_msg,&messaggio,sizeof(messaggio),2,0)<0)
              {
                perror("msgrcv");
                exit(1);
              }

              if(strcmp(messaggio.mtext,"iniziamo")==0)
              {
                
                messaggio.mnumber=number;
                messaggio.mtype=2;

                if(msgsnd(id_msg,&messaggio,sizeof(messaggio),0)<0)
                {perror("msgsnd"); exit(1);}

                else
                printf("P%d, mossa %d\n",id_player,messaggio.mnumber);

                 usleep(rand()%10000);
              }

              if(strcmp(messaggio.mtext,"fine")==0)
              {
                printf("P%d,ESCO\n",id_player);
                exit(0);
              }

              break;

        case 2: //printf("P%d, aspetto il messaggio\n",id_player);
              if(msgrcv(id_msg,&messaggio,sizeof(messaggio),3,0)<0)
              {
                perror("msgrcv");
                exit(1);
              }

              if(strcmp(messaggio.mtext,"iniziamo")==0)
              {
                
                messaggio.mnumber=number;
                messaggio.mtype=3;

                if(msgsnd(id_msg,&messaggio,sizeof(messaggio),0)<0)
                {perror("msgsnd"); exit(1);}

                else
                printf("P%d, mossa %d\n",id_player,messaggio.mnumber);

                usleep(rand()%10000);
              }

              if(strcmp(messaggio.mtext,"fine")==0)
              {
                printf("P%d,ESCO\n",id_player);
                exit(0);
              }

              break;

        case 3: //printf("P%d, aspetto il messaggio\n",id_player);
              if(msgrcv(id_msg,&messaggio,sizeof(messaggio),4,0)<0)
              {
                perror("msgrcv");
                exit(1);
              }

              if(strcmp(messaggio.mtext,"iniziamo")==0)
              {
                
                messaggio.mnumber=number;
                messaggio.mtype=4;

                if(msgsnd(id_msg,&messaggio,sizeof(messaggio),0)<0)
                {perror("msgsnd"); exit(1);}

                else
                printf("P%d, mossa %d\n",id_player,messaggio.mnumber);

                 usleep(rand()%10000);
              }

              if(strcmp(messaggio.mtext,"fine")==0)
              {
                printf("P%d,ESCO\n",id_player);
                exit(0);
              }

              break;

        case 4: //printf("P%d, aspetto il messaggio\n",id_player);
              if(msgrcv(id_msg,&messaggio,sizeof(messaggio),5,0)<0)
              {
                perror("msgrcv");
                exit(1);
              }

              if(strcmp(messaggio.mtext,"iniziamo")==0)
              {
                
                messaggio.mnumber=number;
                messaggio.mtype=5;

                if(msgsnd(id_msg,&messaggio,sizeof(messaggio),0)<0)
                {perror("msgsnd"); exit(1);}

                else
                printf("P%d, mossa %d\n",id_player,messaggio.mnumber);

                usleep(rand()%10000);
              }

              if(strcmp(messaggio.mtext,"fine")==0)
              {
                printf("P%d,ESCO\n",id_player);
                exit(0);
              }

              break;

        case 5: //printf("P%d, aspetto il messaggio\n",id_player);
              if(msgrcv(id_msg,&messaggio,sizeof(messaggio),6,0)<0)
              {
                perror("msgrcv");
                exit(1);
              }

              if(strcmp(messaggio.mtext,"iniziamo")==0)
              {
                
                messaggio.mnumber=number;
                messaggio.mtype=6;

                if(msgsnd(id_msg,&messaggio,sizeof(messaggio),0)<0)
                {perror("msgsnd"); exit(1);}

                else
                printf("P%d, mossa %d\n",id_player,messaggio.mnumber);

                usleep(rand()%10000);
              }

              if(strcmp(messaggio.mtext,"fine")==0)
              {
                printf("P%d,ESCO\n",id_player);
                exit(0);
              }

              break;
    }
  }
}

void J(int id_msg,int numero_partite,int numero_giocatori)
{
  msg messaggio;
  int player_points[numero_giocatori];
  int sum_points[6];

  for(int i=0;i<numero_giocatori;i++)
  sum_points[i]=0;
  

  while(1)
  {
    for(int i=1;i<numero_giocatori+1;i++)
    {
      strcpy(messaggio.mtext,"iniziamo");
      messaggio.mtype=i;

      if(msgsnd(id_msg,&messaggio,strlen(messaggio.mtext)+1,0)<0)
      {
        perror("msgsnd");
        exit(1);
      }

      else
      printf("J: invio %s\n",messaggio.mtext);

       usleep(rand()%10000);
    }

    if(msgrcv(id_msg,&messaggio,sizeof(messaggio),1,0)<0)
    {
      perror("msgrcv");
      exit(1);
    }

    else
    player_points[0]=messaggio.mnumber;
    
    if(numero_giocatori>1)
    {
      if(msgrcv(id_msg,&messaggio,sizeof(messaggio),2,0)<0)
      {
        perror("msgrcv");
        exit(1);
      }

      else
      player_points[1]=messaggio.mnumber;
    }

    if(numero_giocatori>2)
    {
      if(msgrcv(id_msg,&messaggio,sizeof(messaggio),3,0)<0)
      {
        perror("msgrcv");
        exit(1);
      }

      else
      player_points[2]=messaggio.mnumber;
    }

    if(numero_giocatori>3)
    {
      if(msgrcv(id_msg,&messaggio,sizeof(messaggio),4,0)<0)
      {
        perror("msgrcv");
        exit(1);
      }

      else
      player_points[3]=messaggio.mnumber;
    }

    if(numero_giocatori>4)
    {
      if(msgrcv(id_msg,&messaggio,sizeof(messaggio),5,0)<0)
      {
        perror("msgrcv");
        exit(1);
      }

      else
      player_points[4]=messaggio.mnumber;
    }

    if(numero_giocatori>5)
    {
      if(msgrcv(id_msg,&messaggio,sizeof(messaggio),6,0)<0)
      {
        perror("msgrcv");
        exit(1);
      }

      else
      player_points[5]=messaggio.mnumber;
    }

    int valid=0,winner=0;
    

    for(int i=0;i<numero_giocatori;i++)
    { 
      valid=0;
      for(int j=0;j<numero_giocatori;j++)
      {
        if(player_points[i]==player_points[j])
        valid++;

        if(valid==2)
        break;
      }
    }

    if(valid!=2)
    {
      for(int i=0;i<numero_giocatori;i++)
      winner+=player_points[i];

      winner=winner%numero_giocatori;
      
      sum_points[winner]++;


      printf("P: partita n.%d vinta da P%d\n",numero_partite,winner);

      printf("P: classifica temporanea:");
      for(int i=0;i<numero_giocatori;i++)
      printf("P%d=%d ",i,sum_points[i]);
      printf("\n");
      
      numero_partite--;
    }

    else
    printf("P: la partita si rifa!\n");

    if(numero_partite==0)
    break;
  }

  for(int i=1;i<numero_giocatori+1;i++)
    {
      strcpy(messaggio.mtext,"fine");
      messaggio.mtype=i;

      if(msgsnd(id_msg,&messaggio,strlen(messaggio.mtext)+1,0)<0)
      {
        perror("msgsnd");
        exit(1);
      }

       usleep(rand()%10000);
    }

  int max=-1,j=0;

  for(int i=0;i<numero_giocatori;i++)
  {
    if(sum_points[i]>max)
    {
      max=sum_points[i];
      j=i;
    }
  }

  printf("P: torneo vinto da P%d\n",j);

}
int main(int argc, char **argv)
{
  int id_msg;

  if(argc<2)
  {
    printf("Sintax error: ./pari-dispari-generalizzato <n=numero-giocatori> <m=numero-partite>\n");
    exit(1);
  }

  int numero_giocatori=atoi(argv[1]);
  int numero_partite=atoi(argv[2]);

  if(numero_giocatori<1 || numero_giocatori>6 || numero_partite<1)
  {
     printf("Il programma gestisce una serie di m ≥ 1 partite tra 2 ≤ n ≤ 6 giocatori virtuali\n");
     exit(1);
  }

  if((id_msg=msgget(IPC_PRIVATE,IPC_CREAT|IPC_EXCL|0600))<0)
  {
    perror("msgget");
    exit(1);
  }
  
  for(int i=0;i<numero_giocatori;i++)
  {
    pid_t pid=fork();

    if(pid==0)
    P(i,id_msg);
  }

  J(id_msg,numero_partite,numero_giocatori);

  msgctl(id_msg,IPC_RMID,NULL);

  exit(0);
}