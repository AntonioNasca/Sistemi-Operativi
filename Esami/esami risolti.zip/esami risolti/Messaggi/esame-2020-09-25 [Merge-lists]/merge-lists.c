#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/msg.h>

typedef struct 
{
  long mtype;
  char mtext[1024]; 
}msg;

void clear(char *buffer)
{
  char a[strlen(buffer)];
  int x=0;

  for(int i=0;i<strlen(buffer);i++)
  {
    if(buffer[i]!='\n' && buffer[i]!=' ')
    {
      a[x]=buffer[i];
      x++;
    }

    else
    a[x]='\0';
  }

  strcpy(buffer,a);
}

int check(char *frase,char *file1,char *file2)
{
  FILE *fd1=fopen(file1,"r+");
  FILE *fd2=fopen(file2,"r+");
  int is_valid=0;
  char buffer[1024];

  while(1)
  {
    if(fgets(buffer,sizeof(buffer),fd1)==NULL)
    break;

    if(strstr(buffer,frase))
    is_valid++;
  }

  while(1)
  {
    if(fgets(buffer,sizeof(buffer),fd2)==NULL)
    break;

    if(strstr(buffer,frase))
    is_valid++;
  }

  if(is_valid==1)
  return 1;

  else
  return 0;
}

void R1(int id_msg,char *file)
{
  FILE *fd=fopen(file,"r+");
  msg messaggio;
  
  while(1)
  {
     if(fgets(messaggio.mtext,sizeof(messaggio.mtext),fd)==NULL)
     break;
     
     clear(messaggio.mtext);

     messaggio.mtype=1;
     if(msgsnd(id_msg,&messaggio,strlen(messaggio.mtext)+1,0)<0)
     {
       perror("msgsnd");
       exit(1);
     }
     
     //else
     //printf("R1: invio:%s\n",messaggio.mtext);
  }

  strcpy(messaggio.mtext,"fine");

     messaggio.mtype=1;
     if(msgsnd(id_msg,&messaggio,strlen(messaggio.mtext)+1,0)<0)
     {
       perror("msgsnd");
       exit(1);
     }
     
     //else
     //printf("R1: invio %s\n",messaggio.mtext);

  exit(0);
}

void R2(int id_msg,char *file)
{
  FILE *fd=fopen(file,"r+");
  msg messaggio;
  
  while(1)
  {
     if(fgets(messaggio.mtext,sizeof(messaggio.mtext),fd)==NULL)
     break;
     

     clear(messaggio.mtext);
     messaggio.mtype=1;

     if(msgsnd(id_msg,&messaggio,strlen(messaggio.mtext)+1,0)<0)
     {
       perror("msgsnd");
       exit(1);
     }
     
     //else
     //printf("R2: invio:%s\n",messaggio.mtext);
  }

  strcpy(messaggio.mtext,"fine");

     messaggio.mtype=1;
     if(msgsnd(id_msg,&messaggio,strlen(messaggio.mtext)+1,0)<0)
     {
       perror("msgsnd");
       exit(1);
     }
     
     //else
     //printf("R2: invio %s\n",messaggio.mtext);

  exit(0);
}

void P(int id_msg,int *pipe1,char *file1,char *file2)
{
  FILE *pipe_write=fdopen(pipe1[1],"a");
  msg messaggio;
  int finish=0;
  
  close(pipe1[0]);

  while(1)
  {
     if(msgrcv(id_msg,&messaggio,sizeof(messaggio),0,0)<0)
     {
       //perror("msgrcv");
       exit(1);
     }

     if(strcmp(messaggio.mtext,"fine")==0)
     {
       finish++;  

       if(finish==2)
       break;
     }

     if(check(messaggio.mtext,file1,file2)==1)
     {
       //printf("P: invio %s\n",messaggio.mtext);
       fprintf(pipe_write,"%s\n",messaggio.mtext);
       fflush(pipe_write);
     }
  }
}

void W(int *pipe1)
{
  FILE *pipe_read=fdopen(pipe1[0],"r");
  char buffer[1024];

  close(pipe1[1]);

  while(1)
  {
    if(fgets(buffer,sizeof(buffer),pipe_read)==NULL)
    break;

    if(strcmp(buffer,"fine")==0)
    break;
    
    else
    printf("W:%s",buffer);
  }
  
  exit(0);
}

int main(int argc, char **argv)
{
  int id_msg,pipe1[2];

  if(argc<2)
  {
    printf("Sintax error: ./merge-lists <file-1> <file-2>\n");
    exit(1);
  }

  if(pipe(pipe1)<0)
  {
    perror("pipe");
    exit(1);
  }

  if((id_msg=msgget(IPC_PRIVATE,IPC_CREAT|IPC_EXCL|0600))<0)
  {
    perror("msgget");
    exit(1);
  }
  
  if(fork()!=0)
  {
    if(fork()!=0)
    {
      if(fork()!=0)
      {
        P(id_msg,pipe1,argv[1],argv[2]);
      }
      else
      W(pipe1);
    }
    else
    R2(id_msg,argv[2]);
  }
  else
  R1(id_msg,argv[1]);
 
 sleep(1);

 msgctl(id_msg,IPC_RMID,NULL);

 exit(0);
}