#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>
#include <unistd.h>

#define BUFSIZE 1024

void clear(char *frase)
{
  char a[strlen(frase)];
  int x=0;

  for(int i=0;i<strlen(frase);i++)
  {
    if(frase[i]>='A' && frase[i]<='Z')
    frase[i]+=32;

    if(frase[i]!='\n')
    {
      a[x]=frase[i];
      x++;
    }

    else
    a[x]='\0';
  }

  strcpy(frase,a);
}

int IsPalindroma(char *frase)
{
   int len=strlen(frase);
   int i=0,j=len-1,count=0;

   while(i<len)
   {
     if(frase[i]==frase[j])
     count++;

     if(count==len-1)
     return 1;

     i++;
     j--;
   }


   return 0;
}

void R(char *file,const char *pathname1)
{
  FILE *fd=fopen(file,"r+");
  int fifo_fd;
  char buffer[BUFSIZE];

  printf("R: pronto, per lavore con il  file %s\n",file);

  
  if((fifo_fd=open(pathname1,O_WRONLY))<0)
  {
    perror(pathname1);
    unlink(pathname1);
    exit(1);
  }
  
  while(1)
  {
    if(fgets(buffer,sizeof(buffer),fd)==NULL)
    break;

    write(fifo_fd,buffer,strlen(buffer)+1);
    
    //Importante far aspettare 1 secondo
    sleep(1);
  }
  
  strcpy(buffer,"fine");
  write(fifo_fd,buffer,strlen(buffer)+1);
  sleep(1);
  
  exit(0);
}

void P(const char *pathname1,const char *pathname2)
{
  int fifo_fd,fifo_fd2;
  char buffer[1024],buffer2[1024];
  
  if((fifo_fd=open(pathname1,O_RDONLY))<0)
  {
    perror(pathname1);
    unlink(pathname1);
    exit(1);
  }

  if((fifo_fd2=open(pathname2,O_WRONLY))<0)
  {
    perror(pathname2);
    unlink(pathname2);
    exit(1);
  }
  

  while(1)
  {
     read(fifo_fd,buffer,BUFSIZE);

     if(strcmp(buffer,"fine")==0)
     break;

     strcpy(buffer2,buffer);
     clear(buffer2);

     if(IsPalindroma(buffer2)==1)
     {
       write(fifo_fd2,buffer,strlen(buffer)+1);
       sleep(1);
     }
  }
  
  strcpy(buffer,"fine");
  printf("P: invio %s",buffer);
  write(fifo_fd2,buffer,strlen(buffer)+1);
  sleep(1);
  
  unlink(pathname1);
  exit(0);
}

void W(const char *pathname2)
{
  int fifo_fd;
  char buffer[BUFSIZE];
  
  if((fifo_fd=open(pathname2,O_RDONLY))<0)
  {
    perror(pathname2);
    unlink(pathname2);
    exit(1);
  }

  while(1)
  {
    read(fifo_fd,buffer,BUFSIZE);
    
    if(strcmp(buffer,"fine")==0)
    break;

    printf("W: ho letto %s",buffer);
  }

  unlink(pathname2);
  exit(0);
}

int main(int argc, char **argv)
{
   const char *pathname1="/tmp/myfifo1";
   const char *pathname2="/tmp/myfifo2";
   
   mkfifo(pathname1,0700);
   mkfifo(pathname2,0700);

  if(argc<2)
  {
    printf("Sintax error: ./i-palindrome-filter <input file>\n");
    exit(1);
  }

  if(fork()!=0)
  {
    if(fork()!=0)
    {
      P(pathname1,pathname2);
    }
    else
    W(pathname2);
  }
  else
  R(argv[1],pathname1);

  exit(0);
}