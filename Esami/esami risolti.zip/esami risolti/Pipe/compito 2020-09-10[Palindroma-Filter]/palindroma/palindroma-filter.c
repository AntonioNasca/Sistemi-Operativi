#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/sem.h>

//RICORDARSI SEMPRE DI CHIUDERE IL LATO DELLA PIPE CHE NON VIELE UTILIZZATO 
//PERCHE' LA PIPE E UNIDIREZIONALE.

/* PER ESEMPIO:
  SI SCRIVE DA  A->B  A utilizza pipe[1] ma NON utilizza pipe[0]
  e B LEGGE QUELLO CHE ARRIVA DA A utlizza pipe[0] ma non utilizza pipe[1]

  con tre processi A,B E C che hanno questo tipo di comunicazione con le pipe

  A->scrive->pipe1->P
  P->scrive->pipe2->W

  A scrive su pipe[1] ma non utilizza pipe1[0]
  P legge pipe1[0] ma non utilizza pipe1[1]
  P scrive su pipe2[1] ma non utilizza pipe2[0] 
  W legge su pipe2[0] ma non utilizza pipe2[1] pipe1[0] pipe2[0]

  tutto ciò che non viene utilizzato PRIMA di scrivere o leggere bisogna fare le opportune
  chiamate di sistema close(pipe_numeropipe[0/1])
*/
int  IsPalindroma(char *frase)
{
  int len=strlen(frase);
  int i=0,j=len-1;
  int count=0;


  while(i<len)
  {
    if(frase[i]==frase[j])
    count++;

    if(count==len)
    return 1;

    i++,
    j--;
  }
  
  return 0;
}

void R(int *pipe1,char *file)
{
   FILE *fd;
   FILE* writefd = fdopen(pipe1[1], "a");
   char buffer[1024];

   if((fd=fopen(file,"r+"))<0)
   {
     perror(file);
     exit(1);
   }
   
   close(pipe1[0]);
   
   while(1)
   {
     if(fgets(buffer,sizeof(buffer),fd)==NULL)
     break;

     fprintf(writefd,"%s",buffer);
     fflush(writefd);
     //printf("Ho scritto sulla pipe:%s\n", buffer);
   }
  
  exit(0);
}

void P(int *pipe1,int *pipe2)
{
   FILE* readfd = fdopen(pipe1[0], "r");
   FILE* writefd = fdopen(pipe2[1], "a");
   char buffer[1024];
  
  close(pipe1[1]);
  
  while(1)
  {
     if(fscanf(readfd, "%s", buffer)==EOF)
     break;
    
     if(IsPalindroma(buffer)==1)
     {
       //printf("E' palindroma %s\n",buffer);
       fprintf(writefd,"%s\n",buffer);
       fflush(writefd);
     }
  }
  
   
}

void W(int * pipe1,int* pipe2)
{
  FILE* readfd=fdopen(pipe2[0],"r");
  char buffer[1024];
  
  close(pipe1[0]);
  close(pipe1[1]);
  close(pipe2[1]);

 while(1)
 {   
   if(fscanf(readfd,"%s",buffer)==EOF)
   break;
   
   printf("W: %s\n",buffer);
 }
  

}

int main (int argc, char **argv)
{
    int pipe1[2];
    int pipe2[2];

    if(argc<2)
    {
      printf("Erro sintax ./palindroma-filter <file>\n");
      exit(1);
    }

    if (pipe(pipe1)<0)
    {
      perror("Pipe creation failed");
      exit(1);
    }

    if (pipe(pipe2)<0)
    {
      perror("Pipe2 creation failed");
      exit(1);
    }
    
    if(fork()!=0)
    { 
      if(fork()!=0)
      {
        P(pipe1,pipe2);
      }
      else
      W(pipe1,pipe2);
    }
    else
    R(pipe1,argv[1]);
   
  

    
    exit(0);
}